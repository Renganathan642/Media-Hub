# 🚀 Media Hub Backend - Vercel Deployment Guide

## Complete Step-by-Step Setup for Vercel Deployment

---

## 📋 Pre-Deployment Checklist

- [ ] Node.js 18+ installed locally
- [ ] Git repository initialized and pushed to GitHub
- [ ] GitHub account created
- [ ] Vercel account created (vercel.com)
- [ ] PostgreSQL database ready (Supabase or Vercel PostgreSQL)
- [ ] OpenAI API key obtained
- [ ] SendGrid API key obtained

---

## 🔧 Step 1: Prepare Your Project

### Build the project locally
```bash
npm install
npm run build
```

### Test build
```bash
npm start
```

---

## 🌐 Step 2: Set Up Database

### Option A: Using Supabase (Recommended)
1. Go to [supabase.com](https://supabase.com)
2. Create a new project
3. Copy the connection string from Project Settings
4. Format: `postgresql://user:password@host:5432/database?sslmode=require`

### Option B: Using Vercel PostgreSQL
1. In Vercel dashboard, go to Storage
2. Create PostgreSQL database
3. Copy the connection string provided

---

## 📤 Step 3: Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit - Media Hub Backend"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/media-hub-backend.git
git push -u origin main
```

---

## 🚀 Step 4: Deploy to Vercel

### Method A: Using Vercel CLI

```bash
npm i -g vercel
vercel login
vercel
```

Follow the prompts:
- Link to existing project? No
- Set project name: `media-hub-backend`
- Set root directory: `./`
- Override settings? No

### Method B: Using Vercel Dashboard

1. Go to [vercel.com/dashboard](https://vercel.com/dashboard)
2. Click "Add New..." → "Project"
3. Select your GitHub repository
4. Click "Import"
5. Configure Project Settings:
   - Framework: `Other`
   - Build Command: `npm run build`
   - Output Directory: `dist`
   - Install Command: `npm install`

---

## 🔑 Step 5: Configure Environment Variables

In Vercel Dashboard → Your Project → Settings → Environment Variables

Add the following variables:

```env
DATABASE_URL=postgresql://user:password@host:5432/database
JWT_SECRET=your_super_secret_jwt_key_here_min_32_chars
JWT_EXPIRES_IN=7d
OPENAI_API_KEY=sk-...your-openai-api-key
SENDGRID_API_KEY=SG...your-sendgrid-api-key
SENDGRID_FROM_EMAIL=noreply@yourdomain.com
NODE_ENV=production
PORT=3000
```

**⚠️ IMPORTANT:** 
- Use strong random strings for `JWT_SECRET`
- Never commit `.env` files to GitHub
- Generate JWT_SECRET: `openssl rand -hex 32`

---

## 🗄️ Step 6: Initialize Database

After deployment, run migrations:

### Option 1: Using Vercel Functions (if database is accessible)
Create `api/db-init.ts`:
```typescript
import { PrismaClient } from '@prisma/client';

export default async function handler(req, res) {
  const prisma = new PrismaClient();
  
  try {
    await prisma.$executeRawUnsafe('SELECT 1');
    res.status(200).json({ message: 'Database connected' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  } finally {
    await prisma.$disconnect();
  }
}
```

### Option 2: Run locally before deployment
```bash
DATABASE_URL="your_production_db_url" npm run db:push
DATABASE_URL="your_production_db_url" npm run db:seed
```

---

## 📝 Step 7: Verify Deployment

1. Visit your Vercel deployment URL
2. Check the deployment logs in Vercel Dashboard
3. Test API endpoints:

```bash
curl https://your-app.vercel.app/api/health
```

---

## 🔍 Troubleshooting

### Issue: "Module not found"
**Solution:** Ensure `dist/` folder is included in build
```json
{
  "builds": [{ "src": "dist/index.js", "use": "@vercel/node" }]
}
```

### Issue: "Cannot connect to database"
**Solution:** 
- Verify `DATABASE_URL` is correct in environment variables
- Check database firewall allows Vercel IPs
- For Supabase: Enable "Expose as public schema" in settings

### Issue: "Build fails with TypeScript errors"
**Solution:**
```bash
npm run type-check
npm run lint
npm run build
```

### Issue: ".env file not found"
**Solution:** Environment variables are set in Vercel dashboard, not `.env` file in production

---

## 📊 Monitoring & Maintenance

### View Logs
```bash
vercel logs https://your-app.vercel.app
```

### Monitor Performance
- Vercel Dashboard → Analytics
- Check API response times and errors

### Update Code
```bash
git add .
git commit -m "Update: description"
git push origin main
# Vercel auto-deploys on push
```

---

## 🔐 Production Security Checklist

- [ ] JWT_SECRET is strong (32+ characters)
- [ ] Database credentials not in code
- [ ] CORS properly configured
- [ ] Rate limiting enabled
- [ ] HTTPS enforced
- [ ] API keys rotated
- [ ] Error messages don't leak sensitive info
- [ ] Database backups enabled

---

## 📞 Support Resources

- **Vercel Docs:** https://vercel.com/docs
- **Prisma Docs:** https://www.prisma.io/docs
- **Express.js:** https://expressjs.com
- **OpenAI API:** https://platform.openai.com/docs
- **SendGrid:** https://sendgrid.com/docs

---

## 🎉 Success!

Your Media Hub Backend is now live on Vercel!

```
✅ Deployment complete
✅ Environment variables configured  
✅ Database initialized
✅ API endpoints accessible
✅ Monitoring enabled
```

Happy deploying! 🚀

---

*Last Updated: September 2024*
