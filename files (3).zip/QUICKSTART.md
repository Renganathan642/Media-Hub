# 🚀 Quick Start Guide - Media Hub Backend

Get the backend running in 5 minutes!

## Option 1: Docker Compose (Recommended)

### Prerequisites
- Docker & Docker Compose installed

### Steps

```bash
# 1. Clone repository
git clone <repository-url>
cd media-hub-backend

# 2. Set environment variables (optional)
cp .env.example .env
# Edit .env with your API keys if needed

# 3. Start services
docker-compose up -d

# 4. Run database migrations
docker exec media-hub-backend npm run db:migrate

# 5. Seed initial data
docker exec media-hub-backend npm run db:seed

# 6. Create admin account
curl -X POST http://localhost:5000/api/admin/setup \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@mediahub.agency",
    "name": "Admin",
    "password": "ChangeMe123!"
  }'
```

✅ Server running on http://localhost:5000

## Option 2: Local Setup

### Prerequisites
- Node.js 18+
- PostgreSQL 12+

### Steps

```bash
# 1. Install dependencies
npm install

# 2. Create .env file
cp .env.example .env
# Configure DATABASE_URL and other settings

# 3. Create PostgreSQL database
createdb media_hub_db

# 4. Run migrations
npm run db:push

# 5. Seed data
npm run db:seed

# 6. Start server
npm run dev
```

✅ Server running on http://localhost:5000

## Verify Setup

```bash
# Check health
curl http://localhost:5000/health

# Expected response:
# {
#   "success": true,
#   "status": "healthy",
#   "database": "connected"
# }
```

## Create Admin Account

```bash
curl -X POST http://localhost:5000/api/admin/setup \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@mediahub.agency",
    "name": "Admin",
    "password": "YourSecurePassword123!"
  }'

# Response includes admin details
```

## Login & Get Token

```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@mediahub.agency",
    "password": "YourSecurePassword123!"
  }'

# Response:
# {
#   "success": true,
#   "data": {
#     "token": "eyJhbGciOiJIUzI1NiIs...",
#     "admin": { ... }
#   }
# }
```

## Test Contact Form

```bash
curl -X POST http://localhost:5000/api/contact \
  -H "Content-Type: application/json" \
  -d '{
    "name": "John Doe",
    "companyName": "Company Ltd",
    "email": "john@example.com",
    "phone": "+91 1234567890",
    "service": "Creative Design",
    "projectDetails": "We need a brand redesign"
  }'

# Response:
# {
#   "success": true,
#   "data": { "enquiryId": "uuid" },
#   "message": "Thank you. Your enquiry has been received."
# }
```

## Test AI Chatbot

```bash
curl -X POST http://localhost:5000/api/chat/message \
  -H "Content-Type: application/json" \
  -H "X-Visitor-ID: visitor-123" \
  -d '{
    "content": "I need help with social media strategy"
  }'

# Response includes AI response and conversation ID
```

## Get Services List

```bash
curl http://localhost:5000/api/services

# Response includes all services
```

## Admin Dashboard

```bash
# Replace TOKEN with actual JWT token
curl http://localhost:5000/api/admin/dashboard \
  -H "Authorization: Bearer TOKEN"

# Response includes statistics
```

## Access Database (Docker)

```bash
# Using pgAdmin (web interface)
# Visit: http://localhost:5050
# Email: admin@mediahub.agency
# Password: admin

# Or using psql
psql -h localhost -U media_hub_user -d media_hub_db
```

## Common Commands

### Database
```bash
# Run migrations
npm run db:migrate

# Push schema (development)
npm run db:push

# View database
npm run db:studio

# Seed data
npm run db:seed
```

### Development
```bash
# Start dev server
npm run dev

# Build for production
npm run build

# Start production server
npm start

# Type checking
npm run type-check

# Lint code
npm run lint

# Format code
npm run format
```

### Docker
```bash
# Start services
docker-compose up -d

# View logs
docker-compose logs -f backend

# Stop services
docker-compose down

# Remove data volumes
docker-compose down -v

# Rebuild images
docker-compose build --no-cache
```

## Environment Variables

### Essential for Development
```env
DATABASE_URL=postgresql://user:password@localhost:5432/media_hub_db
JWT_SECRET=your-development-secret
NODE_ENV=development
```

### Required for Full Features
```env
SENDGRID_API_KEY=your-sendgrid-key
OPENAI_API_KEY=your-openai-key
```

### Optional
```env
PORT=5000
CORS_ORIGIN=http://localhost:3000
EMAIL_FROM=noreply@mediahub.agency
```

## Troubleshooting

### Database Connection Error

```bash
# Check PostgreSQL is running
docker ps | grep postgres

# Check connection string in .env
# Format: postgresql://user:password@host:port/database
```

### Port Already in Use

```bash
# Change PORT in .env
# Or kill existing process
lsof -i :5000
kill -9 <PID>
```

### AI/Email Not Working

```bash
# These are optional features
# Get API keys from:
# - OpenAI: https://platform.openai.com/api-keys
# - SendGrid: https://app.sendgrid.com/settings/api_keys
```

### Database Already Seeded

```bash
# Reset database (⚠️ deletes all data)
npm run db:push -- --skip-generate

# Or use Prisma Studio
npm run db:studio
# Delete records manually
```

## Next Steps

1. ✅ Backend running
2. ✅ Database connected
3. ✅ Admin account created
4. ⏭️ Connect frontend (see Frontend Integration below)
5. ⏭️ Configure API keys for full features
6. ⏭️ Deploy to production

## Frontend Integration

The frontend should connect to:

```javascript
const API_BASE_URL = 'http://localhost:5000/api';

// Example: Submit contact form
fetch(`${API_BASE_URL}/contact`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    name, email, service, projectDetails
  })
});

// Example: Chat with AI
fetch(`${API_BASE_URL}/chat/message`, {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'X-Visitor-ID': visitorId
  },
  body: JSON.stringify({ content: message })
});
```

## Documentation

- Full API docs: See `README.md`
- Database schema: `prisma/schema.prisma`
- Environment setup: `.env.example`

## Support

- 📧 Email: hello@mediahub.agency
- 📞 Phone: +91 93600 99040
- 🔗 Instagram: @mediahub.official

---

**Happy coding! 🎨**
