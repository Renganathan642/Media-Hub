# 🎨 Media Hub - Backend API

Elite Creative Media & Digital Marketing Agency Backend System

```
╔════════════════════════════════════════════════════════════════╗
║                    MEDIA HUB BACKEND                          ║
║                                                                ║
║  Complete backend system with:                                ║
║  ✨ Contact Form Management                                    ║
║  🤖 AI Chatbot & Lead Qualification                            ║
║  📊 Admin Dashboard                                            ║
║  🎬 Portfolio CMS                                              ║
║  📈 Analytics & Tracking                                       ║
║  🔐 Secure Authentication                                      ║
║  📧 Email Notifications                                        ║
║  🎯 AI Content Generation                                      ║
║                                                                ║
╚════════════════════════════════════════════════════════════════╝
```

## 📋 Table of Contents

- [Installation](#installation)
- [Environment Setup](#environment-setup)
- [Database Setup](#database-setup)
- [Running the Server](#running-the-server)
- [API Documentation](#api-documentation)
- [Features](#features)
- [Project Structure](#project-structure)
- [Security](#security)
- [Deployment](#deployment)

## 🚀 Installation

### Prerequisites

- Node.js >= 18.0.0
- npm >= 9.0.0
- PostgreSQL >= 12
- OpenAI API Key (for AI features)
- SendGrid API Key (for emails)

### Step 1: Clone & Install

```bash
cd media-hub-backend
npm install
```

### Step 2: Environment Setup

```bash
cp .env.example .env
```

Edit `.env` with your configuration:

```env
# DATABASE
DATABASE_URL="postgresql://user:password@localhost:5432/media_hub_db"

# SERVER
NODE_ENV=development
PORT=5000

# JWT
JWT_SECRET=your-super-secret-key-change-in-production
JWT_EXPIRY=7d

# EMAIL
SENDGRID_API_KEY=your-sendgrid-key
EMAIL_FROM=noreply@mediahub.agency

# AI
OPENAI_API_KEY=your-openai-key
OPENAI_MODEL=gpt-4

# CORS
CORS_ORIGIN=http://localhost:3000,https://mediahub.agency
```

### Step 3: Database Setup

#### Create PostgreSQL Database

```bash
# Using psql
createdb media_hub_db
```

#### Initialize Prisma

```bash
# Create migration and push schema
npm run db:push

# OR run migrations
npm run db:migrate

# Seed initial data
npm run db:seed
```

### Step 4: Create Admin Account

Use the setup endpoint:

```bash
curl -X POST http://localhost:5000/api/admin/setup \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@mediahub.agency",
    "name": "Admin",
    "password": "YourSecurePassword123!"
  }'
```

## 🏃 Running the Server

### Development

```bash
npm run dev
```

Server will start on http://localhost:5000

### Production Build

```bash
npm run build
npm start
```

### Verify Server

```bash
# Health check
curl http://localhost:5000/health

# Response:
# {
#   "success": true,
#   "status": "healthy",
#   "database": "connected"
# }
```

## 📚 API Documentation

### Base URL

```
Development: http://localhost:5000/api
Production: https://api.mediahub.agency/api
```

### Authentication

Include JWT token in Authorization header:

```bash
Authorization: Bearer {your_jwt_token}
```

Get token via login:

```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@mediahub.agency",
    "password": "YourPassword"
  }'
```

### Response Format

**Success:**
```json
{
  "success": true,
  "data": {},
  "message": "Operation successful"
}
```

**Error:**
```json
{
  "success": false,
  "error": {
    "code": "ERROR_CODE",
    "message": "Error description"
  }
}
```

## 🔌 API Endpoints

### Contact Form

#### Submit Enquiry
```
POST /contact
```

**Body:**
```json
{
  "name": "John Doe",
  "companyName": "Company Ltd",
  "email": "john@example.com",
  "phone": "+91 1234567890",
  "service": "Creative Design",
  "projectDetails": "We need a complete brand redesign..."
}
```

**Response:**
```json
{
  "success": true,
  "data": { "enquiryId": "uuid" },
  "message": "Thank you. Your enquiry has been received."
}
```

#### Get Enquiries (Admin)
```
GET /contact/enquiries?status=NEW&page=1&limit=10
Authorization: Bearer {token}
```

#### Get Enquiry Details
```
GET /contact/:id
```

#### Update Enquiry Status
```
PUT /contact/:id/status
Authorization: Bearer {token}

Body:
{
  "status": "IN_PROGRESS",
  "notes": "Initial consultation scheduled"
}
```

### Authentication

#### Admin Login
```
POST /auth/login

Body:
{
  "email": "admin@mediahub.agency",
  "password": "password"
}

Response:
{
  "success": true,
  "data": {
    "token": "jwt_token",
    "admin": { "id", "email", "name", "role" }
  }
}
```

#### Get Current User
```
GET /auth/me
Authorization: Bearer {token}
```

#### Logout
```
POST /auth/logout
Authorization: Bearer {token}
```

### Portfolio

#### Get Projects
```
GET /projects?category=Branding&featured=true&page=1&limit=10
```

#### Get Project
```
GET /projects/:id
```

#### Create Project (Admin)
```
POST /projects
Authorization: Bearer {token}

Body:
{
  "title": "Aura Luxe Monograph",
  "category": "Branding",
  "description": "Complete brand identity redesign...",
  "client": "Aura Luxe",
  "year": 2024,
  "imageUrl": "https://...",
  "videoUrl": "https://...",
  "featured": true
}
```

### Services

#### Get Services
```
GET /services?page=1&limit=10
```

#### Get Service
```
GET /services/:id
```

#### Create Service (Admin)
```
POST /services
Authorization: Bearer {token}

Body:
{
  "title": "Creative Design",
  "shortDescription": "Bespoke visual identities",
  "description": "Full description...",
  "order": 1,
  "isActive": true
}
```

### Chat & AI Chatbot

#### Send Message
```
POST /chat/message

Body:
{
  "content": "I need help with my social media strategy",
  "conversationId": "optional-existing-id"
}

Headers:
X-Visitor-ID: visitor-identifier

Response:
{
  "success": true,
  "data": {
    "conversationId": "uuid",
    "message": "AI response...",
    "visitorId": "visitor-id"
  }
}
```

#### Get Conversation History
```
GET /chat/:conversationId
```

#### Qualify Lead
```
POST /chat/qualify

Body:
{
  "conversationId": "uuid",
  "name": "John Doe",
  "email": "john@example.com",
  "company": "Company Ltd",
  "phone": "+91 1234567890"
}
```

### AI Content Generation

#### Generate Instagram Caption
```
POST /ai/generate-caption

Body:
{
  "brand": "Media Hub",
  "topic": "Social media strategy",
  "tone": "professional"
}
```

#### Generate Ad Copy
```
POST /ai/generate-ad-copy

Body:
{
  "product": "Creative Services",
  "targetAudience": "Marketing Directors",
  "benefit": "Increase brand visibility"
}
```

#### Generate Campaign
```
POST /ai/generate-campaign

Body:
{
  "client": "Client Name",
  "industry": "Technology",
  "targetAudience": "Tech-savvy professionals",
  "objective": "Increase conversions",
  "budget": "$50,000",
  "duration": "3 months",
  "platforms": ["Instagram", "LinkedIn", "Google Ads"]
}
```

### Leads Management

#### Get Leads (Admin)
```
GET /leads?status=HOT&page=1&limit=10
Authorization: Bearer {token}
```

#### Get Lead Details
```
GET /leads/:id
Authorization: Bearer {token}
```

#### Update Lead
```
PUT /leads/:id
Authorization: Bearer {token}

Body:
{
  "leadScore": 85,
  "leadStatus": "HOT"
}
```

#### Get Leads Overview
```
GET /leads/analytics/overview
Authorization: Bearer {token}
```

### Analytics

#### Track Event
```
POST /analytics/events

Body:
{
  "eventType": "page_view",
  "page": "/services",
  "data": {}
}

Headers:
X-Visitor-ID: visitor-id
```

#### Get Analytics Overview
```
GET /analytics/overview
Authorization: Bearer {token}
```

#### Get Daily Analytics
```
GET /analytics/daily?days=30
Authorization: Bearer {token}
```

### Admin Dashboard

#### Get Dashboard Stats
```
GET /admin/dashboard
Authorization: Bearer {token}

Response includes:
- Total enquiries
- New enquiries
- Active leads
- Completed projects
- This month enquiries
- Service breakdown
```

#### Export Enquiries
```
POST /admin/export-enquiries
Authorization: Bearer {token}

Response: CSV file
```

## 🎯 Features

### Contact Management
- ✅ Contact form submission
- ✅ Email notifications
- ✅ Enquiry tracking & status management
- ✅ Contact history & interactions

### AI Chatbot
- ✅ Natural language conversations
- ✅ Lead qualification
- ✅ Service recommendations
- ✅ Intent detection

### Content Generation
- ✅ Instagram captions
- ✅ Ad copy
- ✅ Campaign concepts
- ✅ Content ideas
- ✅ Reel concepts

### Admin Dashboard
- ✅ Real-time statistics
- ✅ Enquiry management
- ✅ Lead scoring & tracking
- ✅ Analytics overview
- ✅ Project management
- ✅ Service management

### Analytics
- ✅ Page view tracking
- ✅ CTA performance
- ✅ Visitor tracking
- ✅ Conversion metrics
- ✅ Chatbot performance

### Security
- ✅ JWT authentication
- ✅ Password hashing (bcrypt)
- ✅ Rate limiting
- ✅ CORS protection
- ✅ Helmet security headers
- ✅ Input validation (Zod)

## 📁 Project Structure

```
media-hub-backend/
├── src/
│   ├── index.ts                 # Main application
│   ├── types/                   # TypeScript types
│   ├── middleware/              # Express middleware
│   │   ├── auth.ts
│   │   ├── errorHandler.ts
│   │   └── logging.ts
│   ├── routes/                  # API routes
│   │   ├── auth.ts
│   │   ├── contact.ts
│   │   ├── projects.ts
│   │   ├── services.ts
│   │   ├── chat.ts
│   │   ├── ai.ts
│   │   ├── leads.ts
│   │   ├── analytics.ts
│   │   ├── campaigns.ts
│   │   ├── admin.ts
│   │   └── health.ts
│   ├── services/                # Business logic
│   │   └── aiService.ts
│   └── utils/                   # Utility functions
│       ├── email.ts
│       └── validation.ts
├── prisma/
│   ├── schema.prisma           # Database schema
│   └── seed.ts                 # Database seeding
├── dist/                        # Compiled JS
├── package.json
├── tsconfig.json
├── .env.example
└── README.md
```

## 🔒 Security

### Best Practices Implemented

1. **Authentication**: JWT tokens with expiration
2. **Password Security**: Bcrypt hashing (10 salt rounds)
3. **Rate Limiting**: 100 requests per 15 minutes
4. **Input Validation**: Zod schema validation
5. **SQL Injection Protection**: Prisma ORM
6. **XSS Protection**: Input sanitization
7. **CORS**: Configurable origins
8. **Security Headers**: Helmet middleware
9. **Environment Variables**: No hardcoded secrets
10. **HTTPS**: Recommended for production

### Environment Variables

⚠️ **Never commit `.env` file**

```bash
# Keep these secure:
- JWT_SECRET
- DATABASE_URL
- SENDGRID_API_KEY
- OPENAI_API_KEY
- STORAGE keys
```

## 🚀 Deployment

### Production Checklist

- [ ] Set `NODE_ENV=production`
- [ ] Use strong `JWT_SECRET` (min 32 characters)
- [ ] Configure `CORS_ORIGIN` to your domain
- [ ] Use PostgreSQL in production
- [ ] Enable HTTPS
- [ ] Set up SendGrid API key
- [ ] Set up OpenAI API key
- [ ] Configure monitoring & logging
- [ ] Set up database backups
- [ ] Use environment-specific configs

### Deployment Options

#### Docker

```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY dist ./dist
EXPOSE 5000
CMD ["node", "dist/index.js"]
```

#### Heroku

```bash
heroku create media-hub-backend
heroku addons:create heroku-postgresql:standard-0
git push heroku main
heroku config:set JWT_SECRET=your-secret
```

#### AWS/DigitalOcean/Railway

Use Node.js runtime with environment variables configured.

## 📊 Database Schema

### Key Models

- **Admin**: Admin users
- **ContactEnquiry**: Website form submissions
- **Lead**: Qualified leads from AI chatbot
- **Project**: Portfolio projects
- **Service**: Services offered
- **ChatConversation**: AI chatbot conversations
- **ChatMessage**: Individual messages
- **Campaign**: Generated campaigns
- **ContentGeneration**: AI-generated content
- **AnalyticsEvent**: Page/interaction events

## 🧪 Testing

```bash
# Run tests
npm run test

# Watch mode
npm run test:watch

# Type checking
npm run type-check

# Linting
npm run lint
```

## 📝 Logging

Logs are output to console with timestamps. In production, integrate with:

- Sentry
- LogRocket
- DataDog
- CloudWatch

## 🆘 Troubleshooting

### Database Connection Error
```bash
# Check PostgreSQL is running
psql -U postgres

# Verify DATABASE_URL in .env
```

### Port Already in Use
```bash
# Change PORT in .env or:
lsof -i :5000
kill -9 <PID>
```

### AI API Errors
- Verify OpenAI API key
- Check rate limits
- Ensure proper error handling

### Email Not Sending
- Verify SendGrid API key
- Check email addresses
- Enable "Less Secure Apps" if needed

## 📞 Support

For issues and questions:
- Email: hello@mediahub.agency
- Phone: +91 93600 99040
- Instagram: @mediahub.official

## 📄 License

© 2024 Media Hub. All rights reserved.

---

**Happy coding! 🚀**
